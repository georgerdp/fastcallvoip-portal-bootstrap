# Outbound Profiles (hidden prefixes)

Operators select an outbound profile in WebPhone. The portal prepends a hidden prefix, and FreePBX routes reliably.

## Canonical dial format
UI input: +CC...
PBX dial: 00CC...

## Prefix map
*71.  -> Zadarma-183824
*72.  -> Zadarma-558257
*730. -> TR_GOIP90_CH1
*731. -> TR_GOIP90_CH2
*732. -> TR_GOIP90_CH3
...
*745. -> TR_GOIP90_CH16

## Policy
All users see all profiles in the UI, but calls are blocked if:
- user has no permission for the chosen profile
- destination country code is not allowed for that user
